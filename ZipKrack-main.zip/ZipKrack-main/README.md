<h1 align="center">ZipKrack v1.0</h1>

# ZipKrack
Crack zip files password.
![](zk.png)

# Tested on
- Kali Linux
- Ubuntu
- Termux

# Installation
* apt install python3

* apt install git

* git clone https://github.com/RanaBro22/
* cd ZipKrack

* python3 zipkrack.py

Type `help` for more information.

# Warning
***This tool is only for educational purpose. We are not responsible for any misuse or illegal activities.***
